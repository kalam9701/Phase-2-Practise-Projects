package practice.programs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBconnection 
{
	public static void main(String args[])
	{
		try 
		{
			DBconnection.dbConn();
		} 
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}

	}

	public static Connection dbConn() throws ClassNotFoundException, SQLException
	{
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/db_world","root","Pooja511#");
		System.out.println("Connection Sucessfull");
		return conn;
	}
}



