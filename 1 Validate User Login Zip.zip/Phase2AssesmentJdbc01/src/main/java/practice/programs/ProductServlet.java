package practice.programs;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/ProductDetails")
public class ProductServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		 PrintWriter pw=resp.getWriter();
		 ProductDetails pd=new ProductDetails();
		 pd.setId(Integer.parseInt(req.getParameter("id")));
 		 pw.println("<html><body>");  
 		 resp.setContentType("text/html");
 		

      		try 
      		{
      			Connection conn =DBconnection.dbConn();
          		String sql="select * from Product where id=(?)";
          		PreparedStatement ps=conn.prepareStatement(sql);
          		ps.setInt(1,pd.getId());
          		ResultSet rs=ps.executeQuery();
          		RequestDispatcher rd=req.getRequestDispatcher("index.html");
          		rd.include(req, resp);
         		
          		pw.println("<center><table border=1 width=14% height=10%>");  
          		pw.println("<tr><th>Product Id</th><th>Product Name</th><th>Price</th>"); 
          		while(rs.next()) 
          		{
          			pw.println("<tr><td>" + rs.getInt(1)+ "</td><td>" + rs.getString(2) +"</td><td>"+ rs.getInt(3)+"</td></tr></center>");   
          		}
          		pw.println("</table>");  
          		pw.println("</html></body>"); 
          	}
      		catch (SQLException e)
          	{
          		 e.printStackTrace();
          	} 
          	catch (ClassNotFoundException e)
          	{
    			e.printStackTrace();
    		}
	}

}
